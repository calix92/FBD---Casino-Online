-- -----------------------------------------------------
-- 4. REGISTAR APOSTA
-- -----------------------------------------------------
CREATE   PROCEDURE sp_RegistarAposta
    @sessao_id INT,
    @valor     DECIMAL(10,2),
    @resultado NVARCHAR(50),
    @lucro     DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Guardar a aposta
    INSERT INTO Aposta (sessaoJogo_id, valor, resultado, lucro, dataAposta)
    VALUES (@sessao_id, @valor, @resultado, @lucro, GETDATE());

    -- 2. Atualizar contador de partidas
    UPDATE SessaoDeJogo
    SET numPartidas = numPartidas + 1
    WHERE id = @sessao_id;

    -- 3. Atualizar o saldo do Jogador
    DECLARE @jogador_id INT = (SELECT jogador_id FROM SessaoDeJogo WHERE id = @sessao_id);

    UPDATE Jogador
    SET saldo = saldo + @lucro
    WHERE id = @jogador_id;
END
go

