-- -----------------------------------------------------
-- 1. REGISTAR NOVO JOGADOR
-- -----------------------------------------------------
CREATE   PROCEDURE sp_RegistarJogador
    @nome           NVARCHAR(100),
    @cc             NVARCHAR(20),
    @dataNascimento DATE,
    @email          NVARCHAR(100),
    @password       NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON; -- Ponto e vírgula adicionado

    -- Verificar se email já existe
    IF EXISTS (SELECT 1 FROM Jogador WHERE email = @email)
    BEGIN
        SELECT 'Erro' as Status, 'Email já registado.' as Mensagem;
        RETURN;
    END

    -- Verificar se CC já existe
    IF EXISTS (SELECT 1 FROM Jogador WHERE cc = @cc)
    BEGIN
        SELECT 'Erro' as Status, 'CC já registado.' as Mensagem;
        RETURN;
    END

    INSERT INTO Jogador (nome, cc, dataRegisto, dataNascimento, email, password, saldo, estadoVerificacao)
    VALUES (@nome, @cc, GETDATE(), @dataNascimento, @email, @password, 0.00, 1);

    SELECT 'Sucesso' as Status, 'Jogador criado com sucesso!' as Mensagem;
END
go

