-- -----------------------------------------------------
-- 3. INICIAR SESSÃO
-- -----------------------------------------------------
CREATE   PROCEDURE sp_IniciarSessao
    @jogador_id INT,
    @mesa_id    INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO SessaoDeJogo (mesa_id, jogador_id, numPartidas, dataInicio)
    VALUES (@mesa_id, @jogador_id, 0, GETDATE());

    SELECT SCOPE_IDENTITY() AS sessao_id;
END
go

